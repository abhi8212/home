import React from 'react';
import Image from 'next/image';
import c1 from '../images/c1.png';
import c2 from '../images/c2.png';
import c3 from '../images/c3.png';
import c4 from '../images/c4.png';

const data = [
  { id: 1, name: 'Learn And Play', role: 'With the criteria of playing and learning together, children will have a comfortable.', image: c1, bgColor: 'bg-blue-400' },
  { id: 2, name: 'Nutritious Meal', role: 'Children meals need to be provided with all the nutrients necessary for a day of play.', image: c2, bgColor: 'bg-green-400' },
  { id: 3, name: 'Great Teachers', role: 'Experienced and dedicated teachers team will help your child develop more in all aspects.', image: c3, bgColor: 'bg-yellow-400' },
  { id: 4, name: 'Cute Environment', role: 'The colorful environment at Kindori is suitable for children’s age, making them more accessible.', image: c4, bgColor: 'bg-pink-400' }
];

const WhyChoose = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-9 ">
      <div className="pb-4 text-center">
        <p>WHY CHOOSE US</p>
        <p className="text-2xl font-bold">Our Core Values</p>
        <p className="pb-4">
          With Kindori, we always put the quality of teaching children first, please rest assured when sending children to Kindori Kindergarten.
        </p>
      </div>

      <div className="flex justify-center text-white">
        {data.map(item => (
          <div key={item.id} className={`w-full ${item.bgColor} m-4 p-7 border rounded-lg shadow-md transform transition duration-300 ease-in-out hover:shadow-xl`}>
            <div className="flex flex-col items-center">
              <div className="mt-7 relative w-24 h-24 mb-6 rounded-full  border-black">
                <Image src={item.image} alt="Profile image" layout="fill" objectFit="cover" className="rounded-full" />
              </div>
              <h5 className="mb-1 text-xl font-medium ">{item.name}</h5>
              <span className="text-sm  mx-4">{item.role}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default WhyChoose;
