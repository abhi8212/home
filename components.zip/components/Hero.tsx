import React from 'react';

const Hero = () => {
  return (
    <div className='flex items-center h-screen bg-fixed bg-center bg-cover custom-img'>
      {/* Overlay */}
      <div className='absolute top-0 left-0 right-0 bottom-0' />
      <div className='flex flex-col text-white ml-10 max-w-sm'>
        <div className='bg-opacity-75 p-5 rounded-lg'>
          <h2 className='text-3xl md:text-5xl font-bold text-blue-950'>A Brighter Future For All.</h2>
          <p className='text-lg md:text-xl leading-relaxed text-black' >The Universe is one great kindergarten for man. 
            Everything that exists has brought with it its own peculiar lesson.</p>
            <button className='mt-3 px-3 py-1 border text-sm md:text-base bg-black rounded-md shadow hover:bg-gray-800 transition duration-300'>Book</button>

        </div>
      </div>
    </div>
  );
};

export default Hero;
