import React from 'react'

const Enroll = () => {
  return (
    <div>
  <div className="flex flex-col lg:flex-row items-center pl-11 m-6">
  <div className="lg:w-3/4 lg:mr-4">
    <h2 className="text-2xl font-bold">How To Let Your Child Study At Kindori?</h2>
    <p className="mt-2">Let your child attend Kindori Kindergarten to help your child develop comprehensively in all aspects.</p>
  </div>
  <div className="lg:w-1/4 mt-4 lg:mt-0 ">
    <button className="w-3/4 px-3 py-3 bg-red-500 hover:bg-blue-700 text-white font-bold rounded-full transform transition-all hover:shadow-lg hover:scale-105">Apply Now</button>
  </div>
</div>
    </div>
  )
}

export default Enroll
